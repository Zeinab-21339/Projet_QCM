// =====================================================================
// main.js — Helpers globaux pour l'UI du QCM
// IMPORTANT : Ne PAS dupliquer ici la logique (timer, visibilitychange,
// navigation) qui est gérée dans le <script> inline de quiz.php.
// Toute déclaration `let`/`const` au niveau global de ce fichier
// entrerait en conflit avec le script inline de quiz.php
// (SyntaxError "Identifier '...' has already been declared")
// et empêcherait l'attachement des event listeners (boutons
// Suivant/Précédent inopérants). Tout est encapsulé dans une IIFE.
// =====================================================================
(function () {
  // Bouton "Plein écran" présent uniquement sur quiz.php
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  if (fullscreenBtn) {
    fullscreenBtn.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        const elem = document.documentElement;
        if (elem.requestFullscreen)            elem.requestFullscreen().catch(() => {});
        else if (elem.webkitRequestFullscreen) elem.webkitRequestFullscreen();
        else if (elem.mozRequestFullScreen)    elem.mozRequestFullScreen();
      }
    });
  }
})();
