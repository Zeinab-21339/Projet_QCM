<?php
// ============================================================
//  quiz.php  –  Passage du QCM
//  Page frontend de référence : quiz.html
//  - GET  : affiche les 10 questions aléatoires
//  - POST : reçoit les réponses et redirige vers results.php
//  - Le QCM ne peut être passé QU'EN MODE PLEIN ÉCRAN.
//    Un overlay verrouille la page tant que le plein écran
//    n'est pas activé et le réactive si on en sort.
// ============================================================

require_once 'auth_check.php';
require_once 'config.php';

// ── POST : soumission des réponses ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $reponses_user = $_POST['reponses'] ?? []; // tableau [question_id => valeur_radio]

    if (empty($_SESSION['quiz_questions'])) {
        header('Location: quiz.php');
        exit;
    }

    $questions = $_SESSION['quiz_questions'];
    $score_brut = 0;
    $nb_questions = count($questions);

    // --- Créer la tentative ---
    $stmt = $pdo->prepare(
        'INSERT INTO tentatives (utilisateur_id, score, date) VALUES (?, 0, NOW())'
    );
    $stmt->execute([$_SESSION['user_id']]);
    $tentative_id = $pdo->lastInsertId();

    // --- Enregistrer chaque réponse ---
    $insert_rep = $pdo->prepare(
        'INSERT INTO reponses (tentative_id, question_id, reponse_utilisateur, correcte)
         VALUES (?, ?, ?, ?)'
    );

    foreach ($questions as $q) {
        $qid           = $q['id'];
        $rep_user      = isset($reponses_user[$qid]) ? (int)$reponses_user[$qid] : 0;
        $correcte      = ($rep_user === (int)$q['bonne_reponse']) ? 1 : 0;
        $score_brut   += $correcte;

        $insert_rep->execute([$tentative_id, $qid, $rep_user, $correcte]);
    }

    // --- Calculer la note sur 20 ---
    $note = round(($score_brut / $nb_questions) * 20, 2);

    // --- Mettre à jour le score dans tentatives ---
    $pdo->prepare('UPDATE tentatives SET score = ? WHERE id = ?')
        ->execute([$note, $tentative_id]);

    // --- Nettoyer la session quiz ---
    unset($_SESSION['quiz_questions']);

    // --- Rediriger vers les résultats ---
    header('Location: results.php?tentative=' . $tentative_id);
    exit;
}

// ── GET : démarrage d'un nouveau QCM ───────────────────────

// Sélection de 10 questions aléatoires
$stmt = $pdo->query('SELECT * FROM questions ORDER BY RAND() LIMIT 10');
$questions = $stmt->fetchAll();

// Stockage en session pour valider les réponses au POST
$_SESSION['quiz_questions'] = $questions;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>The Legacy QCM</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* === Overlay de verrouillage plein écran === */
    .lock-overlay {
      position: fixed;
      inset: 0;
      z-index: 10000;
      background: rgba(10, 9, 8, 0.94);
      -webkit-backdrop-filter: blur(10px);
      backdrop-filter: blur(10px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .lock-card {
      background: linear-gradient(180deg, rgba(28,26,23,.98), rgba(19,18,16,.98));
      border: 1px solid var(--gold-600);
      border-radius: var(--radius-lg);
      padding: 2.5rem;
      max-width: 480px;
      width: 100%;
      text-align: center;
      box-shadow: var(--shadow-lg), var(--shadow-gold);
    }
    .lock-card .lock-icon {
      font-size: 3rem;
      color: var(--gold-400);
      display: block;
      margin-bottom: 1rem;
      line-height: 1;
    }
    .lock-card h2 {
      font-family: 'Playfair Display', serif;
      color: var(--gold-400);
      margin-bottom: .5rem;
      font-size: 1.6rem;
    }
    .lock-card p {
      color: var(--text-200);
      margin-bottom: 1.5rem;
      line-height: 1.5;
    }
    .lock-card .btn { width: 100%; justify-content: center; }
    .lock-card .lock-back {
      display: inline-block;
      margin-top: 1.2rem;
      color: var(--text-300);
      font-size: .9rem;
      text-decoration: none;
    }
    .lock-card .lock-back:hover { color: var(--gold-400); }
    .lock-card .lock-warning {
      margin-top: 1rem;
      color: var(--accent-orange);
      font-size: .85rem;
    }
  </style>
</head>
<body>

  <!-- Overlay de verrouillage : visible tant que l'utilisateur n'est pas en plein écran -->
  <div id="lockOverlay" class="lock-overlay">
    <div class="lock-card">
      <i class="bi bi-arrows-fullscreen lock-icon"></i>
      <h2>QCM verrouillé</h2>
      <p>Ce QCM ne peut être passé qu'en mode <strong>plein écran</strong>. Cliquez ci-dessous pour commencer. Quitter le plein écran pendant le QCM déclenche un avertissement.</p>
      <button id="startFullscreenBtn" class="btn btn-gold" type="button">
        <i class="bi bi-play-circle"></i> Lancer le QCM en plein écran
      </button>
      <p id="lockWarningMsg" class="lock-warning" style="display:none"></p>
      <a href="index.php" class="lock-back">← Retour à l'accueil</a>
    </div>
  </div>

  <nav class="the_legacy_house-nav">
    <div class="nav-inner">
      <a href="index.php" class="nav-brand"><span>The Legacy</span> QCM</a>
      <div class="nav-links">
        <a href="history.php"><i class="bi bi-clock-history"></i> Historique</a>
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Déconnexion</a>
      </div>
    </div>
  </nav>

  <div class="page-wrap fade-up">
    <div class="flash flash-info"><i class="bi bi-info-circle"></i> Le QCM doit rester en plein écran. Quitter le plein écran ou changer d'onglet incrémente un avertissement (3 = tentative annulée).</div>

    <div class="qcm-layout">
      <main class="quiz-card">

        <form class="answer-list" action="quiz.php" method="post" id="quizForm">

          <?php foreach ($questions as $index => $q):
            $num = $index + 1;
            $reponses = [
              1 => $q['reponse1'],
              2 => $q['reponse2'],
              3 => $q['reponse3'],
              4 => $q['reponse4'],
            ];
          ?>
          <div class="quiz-question-block" id="question-<?= $num ?>" style="<?= $num > 1 ? 'display:none' : '' ?>">

            <div class="quiz-topbar">
              <span class="tag tag-gold">Question <?= $num ?> sur 10</span>
            </div>
            <div class="quiz-progress"><span style="width: <?= $num * 10 ?>%"></span></div>

            <h1 class="quiz-question"><?= htmlspecialchars($q['question']) ?></h1>

            <?php foreach ($reponses as $val => $texte): ?>
              <label class="answer-option">
                <input type="radio" name="reponses[<?= $q['id'] ?>]" value="<?= $val ?>" required>
                <span><?= htmlspecialchars($texte) ?></span>
              </label>
            <?php endforeach; ?>

          </div>
          <?php endforeach; ?>

          <div class="quiz-actions">
            <button class="btn btn-outline" type="button" id="prevBtn" style="display:none">
              <i class="bi bi-arrow-left"></i> Précédent
            </button>
            <button class="btn btn-gold" type="button" id="nextBtn">
              Suivant <i class="bi bi-arrow-right"></i>
            </button>
            <button class="btn btn-gold" type="submit" id="submitBtn" style="display:none">
              <i class="bi bi-check2-circle"></i> Valider mes réponses
            </button>
          </div>

        </form>
      </main>

      <aside class="side-panel">
        <h2>Surveillance</h2>
        <p><strong>Temps restant :</strong> <span id="timer">10:00</span></p>
        <p><strong>Avertissements :</strong> <span id="warningCount">0</span> / 3</p>
        <ul>
          <li>10 questions différentes</li>
          <li>1 seule bonne réponse par question</li>
          <li>Score final calculé sur 20</li>
        </ul>
        <p><strong>Connecté :</strong> <?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?></p>
      </aside>
    </div>
  </div>

  <script src="js/main.js"></script>
  <script>
  (function () {
    // ===== ÉTAT =====
    let current = 1;
    const total = 10;
    let remaining = 10 * 60;
    let warnings = 0;
    let quizStarted = false;        // true dès la première entrée en plein écran
    let timerInterval = null;
    const MAX_WARNINGS = 3;

    // ===== ÉLÉMENTS =====
    const lockOverlay        = document.getElementById('lockOverlay');
    const startFullscreenBtn = document.getElementById('startFullscreenBtn');
    const lockWarningMsg     = document.getElementById('lockWarningMsg');
    const qcmLayout          = document.querySelector('.qcm-layout');
    const timerEl            = document.getElementById('timer');
    const warningCountEl     = document.getElementById('warningCount');
    const form               = document.getElementById('quizForm');

    // ===== PLEIN ÉCRAN =====
    function requestFullscreen() {
      const elem = document.documentElement;
      const req  = elem.requestFullscreen
                || elem.webkitRequestFullscreen
                || elem.mozRequestFullScreen
                || elem.msRequestFullscreen;
      if (!req) {
        alert('Votre navigateur ne supporte pas le mode plein écran.');
        return;
      }
      try {
        const p = req.call(elem);
        if (p && p.catch) {
          p.catch(() => {
            alert("Impossible d'activer le plein écran. Vérifiez les permissions de votre navigateur.");
          });
        }
      } catch (e) {
        alert("Impossible d'activer le plein écran.");
      }
    }

    function isFullscreen() {
      return !!(document.fullscreenElement
             || document.webkitFullscreenElement
             || document.mozFullScreenElement
             || document.msFullscreenElement);
    }

    function lockQuiz() {
      lockOverlay.style.display = 'flex';
      qcmLayout.setAttribute('inert', '');  // rend les questions/boutons non-interactifs
    }
    function unlockQuiz() {
      lockOverlay.style.display = 'none';
      qcmLayout.removeAttribute('inert');
    }

    startFullscreenBtn.addEventListener('click', requestFullscreen);

    function onFullscreenChange() {
      if (isFullscreen()) {
        // === Entrée en plein écran ===
        unlockQuiz();
        if (!quizStarted) {
          quizStarted = true;       // démarre le QCM (timer + surveillance)
          startTimer();
        }
      } else {
        // === Sortie du plein écran ===
        lockQuiz();
        if (quizStarted) {
          warnings++;
          warningCountEl.textContent = warnings;
          if (warnings >= MAX_WARNINGS) {
            alert('Trop de sorties du plein écran. La tentative est annulée.');
            window.location.href = 'index.php';
          } else {
            lockWarningMsg.textContent =
              '⚠ Avertissement ' + warnings + '/' + MAX_WARNINGS +
              ' — vous avez quitté le plein écran. Recliquez sur le bouton pour reprendre.';
            lockWarningMsg.style.display = 'block';
          }
        }
      }
    }
    document.addEventListener('fullscreenchange',       onFullscreenChange);
    document.addEventListener('webkitfullscreenchange', onFullscreenChange);

    // ===== TIMER =====
    function startTimer() {
      if (timerInterval) return;
      timerInterval = setInterval(() => {
        remaining = Math.max(0, remaining - 1);
        const m = String(Math.floor(remaining / 60)).padStart(2, '0');
        const s = String(remaining % 60).padStart(2, '0');
        if (timerEl) timerEl.textContent = `${m}:${s}`;
        if (remaining === 0) {
          clearInterval(timerInterval);
          alert('Temps écoulé ! Vos réponses sont envoyées automatiquement.');
          form.submit();
        }
      }, 1000);
    }

    // ===== NAVIGATION ENTRE QUESTIONS =====
    function showQuestion(n) {
      document.querySelectorAll('.quiz-question-block').forEach(el => el.style.display = 'none');
      document.getElementById('question-' + n).style.display = '';
      document.getElementById('prevBtn').style.display   = n > 1     ? '' : 'none';
      document.getElementById('nextBtn').style.display   = n < total ? '' : 'none';
      document.getElementById('submitBtn').style.display = n === total ? '' : 'none';
    }

    document.getElementById('nextBtn').addEventListener('click', () => {
      const qBlock  = document.getElementById('question-' + current);
      const checked = qBlock.querySelector('input[type="radio"]:checked');
      if (!checked) { alert('Veuillez sélectionner une réponse avant de continuer.'); return; }
      if (current < total) { current++; showQuestion(current); }
    });

    document.getElementById('prevBtn').addEventListener('click', () => {
      if (current > 1) { current--; showQuestion(current); }
    });

    // ===== SOUMISSION =====
    form.addEventListener('submit', function (e) {
      for (let i = 1; i <= total; i++) {
        const qBlock = document.getElementById('question-' + i);
        if (!qBlock.querySelector('input[type="radio"]:checked')) {
          e.preventDefault();
          alert('Question ' + i + ' : aucune réponse sélectionnée.');
          current = i;
          showQuestion(i);
          return;
        }
      }
    });

    // ===== ANTI-TRICHE : changement d'onglet =====
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && quizStarted) {
        warnings++;
        warningCountEl.textContent = warnings;
        if (warnings >= MAX_WARNINGS) {
          alert("Trop de changements d'onglet détectés. La tentative est annulée.");
          window.location.href = 'index.php';
        }
      }
    });

    // ===== ÉTAT INITIAL : verrouillé =====
    lockQuiz();
  })();
  </script>
</body>
</html>
