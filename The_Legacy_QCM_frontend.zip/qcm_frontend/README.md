# The Legacy QCM - Frontend

Projet frontend pour une application de génération et de passage de QCM.

## Pages incluses

- `index.html` : page d’accueil
- `register.html` : page d’inscription
- `login.html` : page de connexion
- `quiz.html` : page de passage du QCM
- `results.html` : page de résultats avec correction
- `history.html` : historique et moyenne
- `admin.html` : interface administrateur

## Style

Le design utilise le style sombre et doré inspiré du projet The Legacy House.
Le titre affiché dans l’interface est : **The Legacy QCM**.

## Fonctionnalités représentées côté frontend

- Inscription avec nom, prénom, email et mot de passe
- Connexion utilisateur
- QCM de 10 questions
- 4 réponses possibles par question
- Score sur 20
- Affichage des mauvaises réponses et bonnes réponses
- Historique des tentatives et moyenne
- Interface administrateur pour gérer les utilisateurs et les questions
- Indications anti-triche : plein écran, changement d’onglet, limite de temps
- Design responsive mobile et desktop

## À connecter avec le backend

Les formulaires utilisent actuellement `action="#"`.
Le développeur backend devra les connecter aux fichiers PHP :
- inscription
- connexion
- soumission du QCM
- historique
- administration
